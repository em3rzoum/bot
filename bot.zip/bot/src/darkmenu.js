const darkmenu = (prefix) => {
	return `

            COMANDOS:


  *Comandos do Lil $hiro:*

➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  DUVIDAS? 👇
  WA.me/554291276766
  WA.me/552799013169
╚════════════════════`
}

exports.darkmenu = darkmenu








